# 类加载LoadClass







### 1.加载器层级

##### 1.1 BootstrapClassLoader启动加载器

（1）加载ExtClassLoader

（2）BootstrapClassLoader是用C++编写

（3）BootstrapClassLoader涉及虚拟机本地实现的细节，因此开发者无法获取BootstrapClassLoader的引用

（4）加载核心类库，java.*

##### 1.2.ExtClassLoader标准扩展类加载器

（1）加载扩展库，javax.*，java.ext.dir指定位置的类

##### 1.3.AppClassLoader系统类加载器

（1）加载所有程序的目录

##### 1.4.CustomClassLoader用户自定义加载器

（1）用户自定义加载器，可以加载指定目录

<!--类加载器层级-->

![类加载器层级](images\类加载器层级.jpg)



### 双亲委派

​	1.当某个类要被加载时，先通过询问上级加载器是否已经加载该类， 如果没有，自己才加载。

##### 双亲委派的作用

​	1.通过委派，防止同一个class类被两次加载

​	2.通过分级加载，防止核心java类被修改，保证class执行安全

```java
// The parent class loader for delegation
private final ClassLoader parent;
```

```java
protected Class<?> loadClass(String name, boolean resolve)
    throws ClassNotFoundException
{
    synchronized (getClassLoadingLock(name)) {
        // First, check if the class has already been loaded
        Class<?> c = findLoadedClass(name);
        if (c == null) {
            long t0 = System.nanoTime();
            try {
                if (parent != null) {
                    c = parent.loadClass(name, false);
                } else {
                    c = findBootstrapClassOrNull(name);
                }
            } catch (ClassNotFoundException e) {
                // ClassNotFoundException thrown if class not found
                // from the non-null parent class loader
            }

            if (c == null) {
                // If still not found, then invoke findClass in order
                // to find the class.
                long t1 = System.nanoTime();
                c = findClass(name);

                // this is the defining class loader; record the stats
                sun.misc.PerfCounter.getParentDelegationTime().addTime(t1 - t0);
                sun.misc.PerfCounter.getFindClassTime().addElapsedTimeFrom(t1);
                sun.misc.PerfCounter.getFindClasses().increment();
            }
        }
        if (resolve) {
            resolveClass(c);
        }
        return c;
    }
}
```



```java
protected Class<?> findClass(String name) throws ClassNotFoundException {
    throw new ClassNotFoundException(name);
}
```

AppClassLoader extends URLClassLoader, 而URLClassLoader实现findClass方法

```java

protected Class<?> findClass(final String name)
        throws ClassNotFoundException
    {
        final Class<?> result;
        try {
            result = AccessController.doPrivileged(
                new PrivilegedExceptionAction<Class<?>>() {
                    public Class<?> run() throws ClassNotFoundException {
                        String path = name.replace('.', '/').concat(".class");
                        Resource res = ucp.getResource(path, false);
                        if (res != null) {
                            try {
                                return defineClass(name, res);
                            } catch (IOException e) {
                                throw new ClassNotFoundException(name, e);
                            }
                        } else {
                            return null;
                        }
                    }
                }, acc);
        } catch (java.security.PrivilegedActionException pae) {
            throw (ClassNotFoundException) pae.getException();
        }
        if (result == null) {
            throw new ClassNotFoundException(name);
        }
        return result;
    }
```



defineClass方法加载文件字节码

```java
/*
     * Defines a Class using the class bytes obtained from the specified
     * Resource. The resulting Class must be resolved before it can be
     * used.
     */
    private Class<?> defineClass(String name, Resource res) throws IOException {
        long t0 = System.nanoTime();
        int i = name.lastIndexOf('.');
        URL url = res.getCodeSourceURL();
        if (i != -1) {
            String pkgname = name.substring(0, i);
            // Check if package already loaded.
            Manifest man = res.getManifest();
            definePackageInternal(pkgname, man, url);
        }
        // Now read the class bytes and define the class
        java.nio.ByteBuffer bb = res.getByteBuffer();
        if (bb != null) {
            // Use (direct) ByteBuffer:
            CodeSigner[] signers = res.getCodeSigners();
            CodeSource cs = new CodeSource(url, signers);
            sun.misc.PerfCounter.getReadClassBytesTime().addElapsedTimeFrom(t0);
            return defineClass(name, bb, cs);
        } else {
            byte[] b = res.getBytes();
            // must read certificates AFTER reading bytes.
            CodeSigner[] signers = res.getCodeSigners();
            CodeSource cs = new CodeSource(url, signers);
            sun.misc.PerfCounter.getReadClassBytesTime().addElapsedTimeFrom(t0);
            return defineClass(name, b, 0, b.length, cs);
        }
    }
```



##### 热部署

1.tomcat有自己的模块指定classloader，用于加载同一个类库不同版本



# 初始化Initializing

##### 1.initalizing概念

（1）调用类初始化代码 <clinit>，给静态成员变量赋初始值

（2）final值会被直接放入内存中，只是调用final变量，不需要初始化final变量所在的类。

##### 2.LazyLoading五种情况

（1）虚拟机启动时，被执行的主类必须初始化

（2）new getstatic putstatic invokestatic指令，访问final变量除外

（3）java.lang.reflect反射调用

（4）初始化子类时，父类首先会被初始化

（5）动态语言支持java.lang.invoke.MethodHandle解析的结果为REF_getstatic REF_putstatic REF_invokestatic的方法句柄时，该类必须初始化





# 编译-混合模式

###### 1.解释器parser：bytecode intepreter

​	（1） 解释执行

###### 2.编译器JIT：Just In-Time complier

​	（2）将class文件编译为机器码，然后执行

###### 3.混合模式

​	（1）使用解释器+热点代码编译

​	（2）起始阶段采用解释模式

###### 5.热点代码检测

​	（1）多次被调用的方法（方法计数器：监测方法执行频率）

​	（2）多次被调用的循环（循环计数器：监测循环执行频率）

​	（3）计数器：在限定时间内，该方法被调用的次数，超出该时间段未达到阈值，计数器的值减半（热度衰减机制，热度衰减的周期称为半衰期，该过程在垃圾收集时顺便执行）

​	（4）阈值（默认 : 1500 on client, 10000 on server ）

###### 6.执行

```java
-Xmixed:混合模式
-Xint:使用解释模式，启动很快执行很慢
-Xcomp:使用纯编译模式，执行很快，编译很慢
-XX：CompileThreadhold 设定阈值
-XX：CounterHalfLifeTime 设定半衰期周期时间
```



# Linking 

Linking 

1. Verification
   1. 验证文件是否符合JVM规定
2. Preparation
   1. 静态成员变量赋默认值
3. Resolution
   1. 将类、方法、属性等符号引用解析为直接引用
      常量池中的各种符号引用解析为指针、偏移量等内存地址的直接引用

<!--class cycle-->

![class cycle](images\class cycle.jpg)





# 总结：

1.load-赋值默认值-初始值

2.new - 申请内存-默认值-初始值

