package com.mashibing.jvm.c4_RuntimeDataAreaAndInstructionSet;

public class T01_InvokeStatic {
    public static void main(String[] args) {
        m();
    }

    public static void m() {}
}
