package com.mashibing.jvm.c4_RuntimeDataAreaAndInstructionSet;

public class Hello_03 {
    public static void main(String[] args) {
        Hello_03 h = new Hello_03();
        int i = h.m1();
    }

    public int m1() {
        return 100;
    }
}
