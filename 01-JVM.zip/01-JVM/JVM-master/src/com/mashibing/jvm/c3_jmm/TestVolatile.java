package com.mashibing.jvm.c3_jmm;

public class TestVolatile {
    int i;
    volatile int j;
}
