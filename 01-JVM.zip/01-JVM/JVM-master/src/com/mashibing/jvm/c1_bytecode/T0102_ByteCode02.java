package com.mashibing.jvm.c1_bytecode;

public class T0102_ByteCode02 {
    void m() {
        int i=0;
        int j = i++;
    }
}

