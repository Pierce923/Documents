JVM概念

1.JVM是一种规范，一般JVM指HotSpot VM，是一种默认虚拟机

<!--java从编码到执行-->

<!--JDK JRE JVM关系-->

![java从编码到执行](images\java从编码到执行.jpg)

![JDK JRE JVM关系](images\JDK JRE JVM关系.jpg)





2.JVM支持java、java script、Kotlin、Groovy、JRuby、Jython、Scala。

3.JVM与class文件有关，与什么语言无关，只要能变异成class文件。





