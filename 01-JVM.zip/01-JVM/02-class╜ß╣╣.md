# class结构

1.class文件就是一个二进制流字节流

2.数据结构：u1 u2 u4 u8和 _info表

​	u1:  （1）u指代无符号参数  （2）u1是一个字节



##### 插件

notepad二进制

idea-JClasslib插件 



constant_utf8_info

constant_methodref_info

constant_int









