JVM指令集



### 指令集分类

1.基于寄存器的指令集

2.基于栈的指令集

​	Hotspot中的Local Variable Table=JVM中的寄存器



### 常用的指令

store

load

pop

mul

sub

invoke



##### 指令样例

```java
public class T_01_PlusSign {
    public static void main(String[] args) {
        int i = 8;
        i = i++;
        //i = ++i;
        System.out.println(i);
    }
}

 0 bipush 8    --将单字节的常量推送至栈顶
 2 istore_1		--将栈顶int类型数值存入指定本地变量
 3 iload_1		--将int类型的局部变量压栈
 4 iinc 1 by 1	--将int类型变量增加指定值
 7 istore_1		--将栈顶int类型数值存储指定本地变量
 8 getstatic #2 <java/lang/System.out>		--获取指定类的静态域，并将其值压入栈顶
11 iload_1									--将int类型变量压入栈顶
12 invokevirtual #3 <java/io/PrintStream.println>	--调用实例方法
15 return

```



```java
public class T_01_PlusSign {
    public static void main(String[] args) {
        int i = 8;
        //i = i++;
        i = ++i;
        System.out.println(i);
    }
}

 0 bipush 8		--将单字节的常量推送至栈顶
 2 istore_1		--将栈顶int类型数值存入指定本地变量
 3 iinc 1 by 1	--将int类型变量增加指定值
 6 iload_1		--将int类型的局部变量压栈
 7 istore_1		--将栈顶int类型数值存入指定本地变量
 8 getstatic #2 <java/lang/System.out>	--获取指定类的静态域，并将其值压入栈顶
11 iload_1								--将int类型变量压入栈顶
12 invokevirtual #3 <java/io/PrintStream.println>	--调用实例方法
15 return

```