# Java内存布局



### 普通对象

###### 1.Header对象头

（1）markword为8byte

###### 2.ClassPointer指针

（1）引用类型：-XX:+UseCompressedClassPointers为4byte,不开启为8byte

###### 3.Instance Data实例数据

（1）引用类型：-XX:+UseCompressedOops为4byte, 不开启为8Byte

###### 4.Padding对齐填充

（1）HotSpot自动内存管理系统要求对象起始地址为8byte的倍数。

（2）padding即是占位符



### 数组对象

###### 1.Header对象头

（1）markword为8byte

###### 2.ClassPointer指针

（1）引用类型：-XX:+UseCompressedClassPointers为4byte,不开启为8byte

###### 3.数组长度

​	4byte

###### 4.数组数据

###### 5.Padding对齐填充

（1）HotSpot自动内存管理系统要求对象起始地址为8byte的倍数。

（2）padding即是占位符





### markwork

```c
markOop.hpp
//  64 bits:
//  --------
//  unused:25 hash:31 -->| unused:1   age:4    biased_lock:1 lock:2 (normal object)
//  JavaThread*:54 epoch:2 unused:1   age:4    biased_lock:1 lock:2 (biased object)
//  PromotedObject*:61 --------------------->| promo_bits:3 ----->| (CMS promoted object)
//  size:64 ----------------------------------------------------->| (CMS free block
```

<!--hotspot-markword.jpg-->

![hotspot-markword](images\hotspot-markword.jpg)