# JMM



## 乱序问题

CPU为了提高指令执行效率，会在一条指令执行过程中（比如去内存读数据（慢100倍）），去同时执行另一条指令，前提是，两条指令没有依赖关系

https://www.cnblogs.com/liushaodong/p/4777308.html

写操作也可以进行合并

https://www.cnblogs.com/liushaodong/p/4777308.html

JUC/029_WriteCombining

乱序执行的证明：JVM/jmm/Disorder.java

原始参考：https://preshing.com/20120515/memory-reordering-caught-in-the-act/



### 如何保证特定情况下不乱序

JVM级别如何规范(JSR133)

##### LoadLoad屏障

```
Load1;LoadLoad;Load2
在load2读取之前，LoadLoad保证Load1要读取的数据已经读取完毕。
```

##### StoreStore屏障

```
Store1;StoreStore;Store2
在Store2操作之前，StoreStore保证Store1写入操作已经完成。
```

##### LoadStore屏障

```
Load1;LoadStore;Store2
LoadStore保证Store2操作之前，Load1读取操作已经完成。
```

##### StoreLoad屏障

```
Store1;StoreLoad;Load2
StoreLoad保证Load2操作之前，Store1写入操作已经完成。
```





### volatie实现

1.字节码层面

```
acc_volatile
```

2.JVM层面

volatile内存区的读写都加屏障

```
StoreStoreBarrier
volatile 写操作
StoreLoadBarrier
```

```
LoadLoadBarrier
volatile 读操作
LoadStoreBarrier
```

3.OS和硬件层面

https://blog.csdn.net/qq_26222859/article/details/52235930
hsdis - HotSpot Dis Assembler

windows lock 指令实现 | MESI实现



### synchronized实现

###### 1.字节码层面

```
acc_synchronized
```

###### 2.JVM层面

​	C++调用操作系统提供的同步机制

###### 3.OS和硬件层面

​	X86 lock cmpxchg 

https://blog.csdn.net/21aspnet/article/details/88571740



## 硬件层数据一致性

协议很多

intel 用MESI

https://www.cnblogs.com/z00377750/p/9180644.html

现代CPU的数据一致性实现 = 缓存锁(MESI ...) + 总线锁

读取缓存以cache line为基本单位，目前64bytes

位于同一缓存行的两个不同数据，被两个不同CPU锁定，产生互相影响的伪共享问题

伪共享问题：JUC/c_028_FalseSharing

使用缓存行的对齐能够提高效率





