# java运行时数据空间



##### Runtime Data Area

1. PC 程序计数器
2. JVM Stack
3. Heap
4. Method Area
5. Runtime Constant Pool
6. Native Method Stack
7. Direct Memory



##### PC程序计数器

存放指令位置

虚拟机运行

```java
while(not end){
	取PC中的位置，找到对应位置的指令;
	执行该指令;
	PC++;
}

```





##### JVM stack 栈

1.JVM stack每个线程被创建时会被创建，线程独享。

2.JVM stack用于存储一组栈帧（Frame）



##### Frame 栈帧

每次方法被调用就会创建一个对应的Frame。

方法执行完毕或者异常，Frame就会被销毁。

一个方法A调用另一个方法B时，A的Frame停止，新的Frame被创建赋予B，执行完毕后，将计算结果传递给A，A继续执行。





##### Frame内部结构

1.Local Variable Table 局部变量

2.Operand Stack 操作数栈

​	对于long的处理(store and load)，多数虚拟机的实现都是原子的，没必要加volatile

3.Dynamic Linking 动态链接

​	https://blog.csdn.net/qq_41813060/article/details/88379473 

4.Return address 返回值

​	a()->b()，方法a调用了方法b，b方法的返回值放在什么地方。

<!--JVMStack-add指令.jpg-->

<!--JVMStacks-newObject.jpg-->

![JVMStack-add指令](images\JVMStack-add指令.jpg)

![JVMStacks-newObject](images\JVMStacks-newObject.jpg)



##### Direct Memory

1.JVM可以直接访问内核空间的内存（OS管理的内存）

2.NIO： 提高效率，实现zero copy



##### Method Area

1.Perm Space(<1.8)

​	字符串常量位于PermSpace

​	FGC不会清理

​	大小启动的时候指定，不能变

2.Meta Space(>=1.8)

​	字符串常量位于堆

​	会触发FGC清理

​	不设定时，最大就是物理内存